
//1.	Write a program to generate the Fibonacci series.
//2.	Write a program to generate the non-Fibonacci series.
//3.	Input a number, generate that many numbers of the non-Fibonacci series.
//4.	Write a program to determine if an inputted number is prime or composite.
//5.	Write a program to print all prime numbers till a user supplied upper limit.
//6.	Write a program to add the digits of a user supplied integer.
//Note: There should be no string operations. All operations should be strictly numeric.
//7.	Write a program to reverse the digits of a user supplied integer.
//Note: There should be no string operations. All operations should be strictly numeric. 
//8.	Write a program to test if an inputted number is an Armstrong number or not.
//9.	Write a program to display the prime factors of an inputted number.
//10.	Write a program to calculate the GCD of a number.
//11.	Write a program to calculate the LCM of two numbers.
//12.	Generate the following sequences:
//1,-2,4,-8,16,-32...  [Numbers double with alternating sign]
//0,1,3,6,10,15,21... [Difference between nos increases by +1]
//   		1,3,6,8,11,13,16... [Difference between nos is: +2, +3, +2 �]
//13.	Write a program to print an inputted integer in its binary representation.
//14.	Write a program to convert an inputted number from any base to any other base.
//15.	Convert an inputted number in the range 0-9999 into words. 
import java.util.*;

public class NumberMagic {
	public static void FibonacciSeries(int no) {
		int n1 = 0, n2 = 1, n3, i;
		System.out.print(n1 + " " + n2); // as first two numbers are 0,1;
		for (i = 2; i < no; ++i) {
			n3 = n1 + n2;
			System.out.print(" " + n3);
			n1 = n2;
			n2 = n3;
		}
		System.out.println();

	}

	public static boolean ArmstrongNumber(int no) {
		int no2 = no;
		int no3 = no;
		double isum = 0;
		int icnt = 0;
		while (no2 != 0) {
			icnt++;                      //counting the number of digits
			no2 = no2 / 10;
		}
		while (no != 0) {
			isum = isum + Math.pow(no % 10, icnt);    //calculating the power of each digit
			no = no / 10;
		}
		if ((int) isum == no3) {               //if sum of the powers of all digit equal to the number its an armstrong
			return true;

		}
		return false;
	}

	public static void PrimeSeries(int no) {
		int icnt = 0;
		for (int k = 2; k <= no; k++) {
			for (int i = 2; i <= k / 2; i++) // iterating only till half of the number to reduce the time complexity
			{
				if ((k % i) == 0) {
					icnt++;
					break;
				}
			}
			if (icnt == 0) {
				System.out.println(k);
			}
			icnt = 0;
		}
	}

	public static int AddDigits(int no) {
		int sum = 0;
		while (no != 0) {            
			sum = sum + (no % 10);         //adding the digits and dividing the number by 10
			no = no / 10;
		}
		return sum;
	}

	public static int ReverseDigits(int no) {
		int idigit = 0;
		while (no != 0) {                           //if no is 123 idigit will have 0*10+3 for first iteration
			idigit = idigit * 10 + (no % 10);
			no = no / 10;
		}
		return idigit;
	}

	public static void PrimeFactor(int no) {
		for (int i = 2; i <= Math.sqrt(no); i++) {
			while (no % i == 0) {
				System.out.print(i + " ");
				no = no / i;
			}
		}
		if (no > 2) {
			System.out.print(no);          //prime numbers
		}
		System.out.println();
	}

	public static int gcd(int a, int b) {
		if (b == 0)
			return a;
		return gcd(b, a % b);
	}

	public static int lcm(int a, int b) {
		return a * b / (gcd(a, b));
	}

	public static void nonFibonacci(int no) {
		int a, b, c, d, x;
		a = 0;
		int n = 0;
		b = 1;
		c = 0;
        int icnt=0;
		while (c <= no || icnt !=no) {    
			c = a + b;
			a = b;
			b = c;
			d = a + b;
			for (x = c + 1; x < d; x++) {  //traversing between two fibonacci numbers
				if (x <= no || icnt!=no) {
					System.out.print(x + " ");
					icnt++;
					

				} else {
					
					break;
				}

			}
		}
		System.out.println();
	}

	public static void IntegertoBinary(int no) {
		StringBuilder str = new StringBuilder();
		while (no != 0) {
			str.append(no % 2);
			no = no / 2;
		}
		str.reverse();              //if the number is 315 we do its mod add it to the string then divide it by 2 again
		System.out.println(str);   //we reverse the string 
	}

	public static void sequence() {
		System.out.print(1 + " ");
		int icnt = 1;
		for (int i = 1; i <= 9; i++) {
			icnt++;
			if (icnt % 2 == 0) {
				System.out.print(-(i * 2) + " ");
			} else {
				System.out.print(i * 2 + " ");
			}

		}
		System.out.println();
		System.out.println("Sequence 2");
		int i = 0;
		System.out.print(0 + " ");
		int k = 1;
		int icnt2 = 0;
		while (icnt2 != 10) {
			k = k + i;
			System.out.print(k + " ");
			i++;
			k++;
			icnt2++;
		}
	}

	public static boolean CompositeOrPrime(int no) {

		for (int i = 2; i <= no / 2; i++) {
			if ((no % i) == 0) {
				return true;
			}
		}

		return false;

	}

	public static String convert(String n, int b1, int b2) {
		if (b1 == b2)
			return n;
		int deci = 0;
		if (b1 != 10)
			deci = getDecimal(n, b1);
		String result = "";
		if (deci == 0)
			result = "0";
		while (deci != 0) {
			int d = deci % b2;
			if (d < 10)
				result = d + result;
			else if (d == 10)
				result = 'A' + result;
			else if (d == 11)
				result = 'B' + result;
			else if (d == 12)
				result = 'C' + result;
			else if (d == 13)
				result = 'D' + result;
			else if (d == 14)
				result = 'E' + result;
			else if (d == 15)
				result = 'F' + result;
			deci /= b2;
		}
		return result;
	}

	public static int getDecimal(String n, int base) {
		int d = 0;
		int num = 0;
		int p = 0;
		for (int i = n.length() - 1; i >= 0; i--) {
			char ch = n.charAt(i);
			switch (ch) {
			case '0':
				num = 0;
				break;
			case '1':
				num = 1;
				break;
			case '2':
				num = 2;
				break;
			case '3':
				num = 3;
				break;
			case '4':
				num = 4;
				break;
			case '5':
				num = 5;
				break;
			case '6':
				num = 6;
				break;
			case '7':
				num = 7;
				break;
			case '8':
				num = 8;
				break;
			case '9':
				num = 9;
				break;
			case 'A':
				num = 10;
				break;
			case 'B':
				num = 11;
				break;
			case 'C':
				num = 12;
				break;
			case 'D':
				num = 13;
				break;
			case 'E':
				num = 14;
				break;
			case 'F':
				num = 15;
				break;
			}
			d += num * (int) Math.pow(base, p);
			p++;
		}
		return d;
	}

	static void ConvertToWords(char[] num) {
		// Get number of digits
		// in given number
		int len = num.length;

		if (len == 0) {
			System.out.println("empty string");
			return;
		}
		if (len > 4) {
			System.out.println("Length more than 4 is not supported"); //as the range is 0-999
			return;
		}

		String[] single_digits = new String[] { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
				"nine" };

		String[] two_digits = new String[] { "", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
				"sixteen", "seventeen", "eighteen", "nineteen" };

		/*
		 * The first two string are not used, they are to make array indexing simple
		 */
		String[] tens_multiple = new String[] { "", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy",
				"eighty", "ninety" };

		String[] tens_power = new String[] { "hundred", "thousand" };

		/* Used for debugging purpose only */
		System.out.print(String.valueOf(num) + ": ");

		/* For single digit number */
		if (len == 1) {
			System.out.println(single_digits[num[0] - '0']);
			return;
		}

		/*
		 * Iterate while num is not '\0'
		 */
		int x = 0;
		while (x < num.length) {

			/* Code path for first 2 digits */
			if (len >= 3) {
				if (num[x] - '0' != 0) {
					System.out.print(single_digits[num[x] - '0'] + " ");
					System.out.print(tens_power[len - 3] + " ");
					// here len can be 3 or 4
				}
				--len;
			}

			/* Code path for last 2 digits */
			else {
				/*
				 * Need to explicitly handle 10-19. Sum of the two digits is used as index of
				 * "two_digits" array of strings
				 */
				if (num[x] - '0' == 1) {
					int sum = num[x] - '0' + num[x + 1] - '0';
					System.out.println(two_digits[sum]);
					return;
				}

				/* Need to explicitely handle 20 */
				else if (num[x] - '0' == 2 && num[x + 1] - '0' == 0) {
					System.out.println("twenty");
					return;
				}

				else {
					int i = (num[x] - '0');
					if (i > 0)
						System.out.print(tens_multiple[i] + " ");
					else
						System.out.print("");
					++x;
					if (num[x] - '0' != 0)
						System.out.println(single_digits[num[x] - '0']);
				}
			}
			++x;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sobj = new Scanner(System.in);
		IntegertoBinary(11);
		sequence();
		if (CompositeOrPrime(10)) {
			System.out.println("Composite");
		} else {
			System.out.println("Prime");
		}
		if (ArmstrongNumber(153)) {
			System.out.println("Armstrong Number");
		} else {
			System.out.println("not an Armstrong number");
		}
		System.out.println("enter the number of integer you want in your non fibonacci series");
		int no5 = sobj.nextInt();
		nonFibonacci(no5);
		System.out.print("Enter the number: ");
		String n = sobj.next();
		n = n.toUpperCase();
		System.out.print("Source base: ");
		int s = Integer.parseInt(sobj.next());
		System.out.print("Destination base: ");
		int d = Integer.parseInt(sobj.next());
		String r = convert(n, s, d);
		System.out.println(r);
		System.out.println("enter the number");
		String no9 = sobj.next();
	    ConvertToWords(no9.toCharArray());

	}

}
