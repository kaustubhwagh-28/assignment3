
//******************************************
//1.	Write a program to display the first 10 positive integers.
//2.	Write a program to print the first 10 even numbers.
//3.	Write a program to generate the multiplication table of a given number. 
//4.	Write a program to find the sum of the first 20 odd numbers.
//5.	Write a program to calculate the factorial of an inputted integer.
//6.	Write a program to keep inputting numbers until the user enters a 0. Then, calculate average of all the numbers.

package loops;
import java.util.*;

public class Loops {
public static void positive(int no)
{
	for(int i=1;i<=no;i++)
	{
		System.out.println(i);
	}
	
}
public static void EvenNumber(int no)
{
	for(int i=2;i<=no*2;i=i+2)
	{
		System.out.println(i);
	}
	
}
public static int OddNumberSum(int no)
{
	int sum=0;
	for(int i=1;i<=no*2;i=i+2)
	{
	 sum=sum+i;
	}
	return sum;
	
}
public static long factorial(int no)
{
	long ians=1;
	for(int i=1;i<=no;i++)
	{
	 ians=ians*i;
	}
	return ians;
	
}
public static void table(int no)
{
	int ians=1;
	for(int i=1;i<=10;i++)
	{
		System.out.print(i*no+" ");
		
	}
}
public static float average()
{
	Scanner sobj=new Scanner(System.in);
	int sum=0;
	int icnt=0;
	int num=0;
	System.out.println("Enter the numbers");
	while((num=sobj.nextInt())!=0)
	{
		 icnt=icnt+1;
		 sum=sum+num;
	}
	return (float)sum/icnt;
}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sobj=new Scanner(System.in);
		positive(10);
		EvenNumber(10);
		System.out.println(OddNumberSum(20));
		System.out.println("enter the number");
		int no=sobj.nextInt();
		System.out.println(factorial(no));
		System.out.println("enter the number of which you want table");
		int n2=sobj.nextInt();
		table(n2);
    System.out.println(average());
    
	}

}
