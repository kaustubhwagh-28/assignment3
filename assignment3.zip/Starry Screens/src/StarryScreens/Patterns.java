package StarryScreens;

public class Patterns {
	public static void Pyramid(int no) {
		System.out.println("Pyramid");
		for (int i = 1; i <= no; i++) {
			for (int j = 1; j <= i * 2 - 1; j++) {
				System.out.print("*");
			}
			System.out.println("");
		}
		System.out.println("");
	}

	public static void DiamondStar(int no) {
		System.out.println("DiamondStar");
		for (int i = 1; i <= no; i++) {
			for (int j = 1; j <= i * 2 - 1; j++) {
				System.out.print("*");
			}
			System.out.println("");
		}
		for (int i = no - 1; i >= 1; i--) {
			for (int j = 1; j <= i * 2 - 1; j++) {
				System.out.print("*");
			}
			System.out.println("");

		}
		System.out.println(" ");
	}

	public static void OutlineDiamondStar(int no) {
		System.out.println("OutLineDiamondStar");
		for (int i = 1; i <= no; i++) {
			for (int j = 1; j <= i * 2 - 1; j++) {
				if ((j == 1) || (j == (i * 2 - 1))) {
					System.out.print("*");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println("");
		}
		for (int i = no - 1; i >= 1; i--) {
			for (int j = 1; j <= i * 2 - 1; j++) {
				if ((j == 1) || (j == (i * 2 - 1))) {
					System.out.print("*");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println("");

		}
		System.out.println(" ");

	}

	public static void PascalPyramid(int no) {
		System.out.println("PascalPyramid");
		for (int i = 1; i <= no; i++) {
			for (int j = 1; j <= i * 2 - 1; j++) {
				if (j <= (i * 2) / 2 || i == 1) {
					System.out.print(j);
				} else {
					int k = j - 1;
					while (j <= i * 2 - 1) {
						k = k - 1;
						System.out.print(k);

						j++;
					}
				}
				
			}
			System.out.println(" ");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pyramid(4);
		DiamondStar(4);
        OutlineDiamondStar(4);
		PascalPyramid(4);
	}

}
